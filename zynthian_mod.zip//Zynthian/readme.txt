This is an alternative edit page for all synths which resembles Zynthian edit page view
